﻿function calculateTotal() {
    const inputList = document.getElementById('input-list').value;
    const lines = inputList.split('\n');
    let transactions = [];
    let currentTransaction = [];
    let totalAmount = 0;
    let repayAmount = 0;
    let failedAmount = 0;

    // 取引を時間ごとに分割
    lines.forEach(line => {
        if (line.match(/\d{2}:\d{2}/) && currentTransaction.length > 0) {
            transactions.push(currentTransaction);
            currentTransaction = [];
        }
        currentTransaction.push(line);
    });

    if (currentTransaction.length > 0) {
        transactions.push(currentTransaction);
    }

    const outputSection = document.getElementById('output-section');
    outputSection.innerHTML = ''; // 前の出力をクリア

    // 各取引を処理
    transactions.forEach(transaction => {
        let num = 0;
        let amount = 0;
        let time = '';
        let status = ''; // 取引の状態（取引完了、返金完了、取引失敗など）

        transaction.forEach(line => {
            if (line.match(/\d{2}:\d{2}/)) {
                time = line; // 時間を取得
            }

            if (line.includes('円') && !(line.includes('合計') || line.includes('--'))) {
                const readAmount = convertToNumber(transaction[num - 1]);
                if (!isNaN(readAmount)) {
                    amount += Math.abs(readAmount);

                    status = transaction[num + 1]; // 取引の状態を取得
                    switch (status) {
                        case '返金完了':
                            repayAmount += amount;
                            break;
                        case '取引失敗':
                            failedAmount += amount;
                            totalAmount += amount;
                            break;
                        default:
                            totalAmount += amount;
                            break;
                    }
                }
            }
            ++num;
        });

        // 取引をリストに出力（ステータスも含める）
        const transactionDiv = document.createElement('div');
        transactionDiv.className = 'output-item';
        transactionDiv.innerHTML = `
            <div class="transaction-row">
                <div class="time">${time}</div>
                <div class="amount">${amount.toLocaleString()} 円</div>
                <div class="status">${status}</div>
            </div>`;
        outputSection.appendChild(transactionDiv);
    });

    // 合計金額を計算
    let finalAmount = totalAmount - repayAmount - failedAmount;
    document.getElementById('total-amount').textContent = '合計金額: ' + totalAmount.toLocaleString() + ' 円';
    document.getElementById('repay-amount').innerHTML = '返金完了: <span style="color: black;">' + repayAmount.toLocaleString() + ' 円</span>';
    document.getElementById('failed-amount').innerHTML = '取引失敗: <span style="color: black;">' + failedAmount.toLocaleString() + ' 円</span>';
    document.getElementById('final-amount').textContent = '(合計) - (返金) - (失敗) = ' + finalAmount.toLocaleString() + ' 円';
}


function convertToNumber(str) {
    return parseFloat(str.replace(/,/g, ''));
}

// ページ読み込み時に日付を当日に設定
window.onload = function() {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('date-picker').value = today;
};

// グローバル変数として精算済と未精算の合計金額を定義
let totalSettledAmount = 0;
let totalBlueAmount = 0; // 青色枠の合計金額（未精算）

// 精算済と未精算の合計金額を出力する関数
function displayFinalTotal() {
    const finalTotal = totalSettledAmount + totalBlueAmount;
    document.getElementById('final-total').textContent = '精算済 + 未精算 合計金額: ' + finalTotal.toLocaleString() + ' 円';
}

// CSVを解析して、クレジットのPayPayのみを合計する関数
function parseCSV(content) {
    const rows = content.split('\n');
    totalSettledAmount = 0; // 精算済の合計金額を初期化
    const selectedDate = document.getElementById('date-picker').value; // 選択された日付を取得

    // 開始時刻：選択した日付の04:00
    const startTime = new Date(selectedDate + 'T04:00:00');

    // 終了時刻：次の日の03:59
    const endDate = new Date(selectedDate);
    endDate.setDate(endDate.getDate() + 1); // 日付を1日増加
    const endTime = new Date(endDate.toISOString().split('T')[0] + 'T03:59:59');

    const csvTimes = []; // 照合用の時間リスト

    rows.forEach(row => {
        const cols = row.split(','); // カンマ区切りで分割
        if (cols.length > 1 && cols[1]) { // cols[1]が存在するか確認
            const dateTimeStr = cols[1]; // 日時がCSVの2列目にあることを想定
            const serviceType = cols[0]; // 1列目に「PayPay」があるか確認
            const match = dateTimeStr.match(/\d{2}:\d{2}/); // 時間を「hh:mm」形式で取得
            const amountStr = cols[6]; // 金額が最後の列にあることを想定

            if (serviceType.includes('PayPay') && match) {
                // 時間のフォーマット修正
                const [monthDay, time] = dateTimeStr.split(' ');
                const [month, day] = monthDay.split('/');
                const transactionTime = new Date(`${new Date().getFullYear()}-${month}-${day}T${time}:00`);

                // 04:00から次の日03:59の範囲内であることを確認
                if (transactionTime >= startTime && transactionTime <= endTime) {
                    // CSVの時間と金額をオブジェクトとして保存
                    const amount = parseFloat(amountStr.replace(/,/g, ''));
                    csvTimes.push({ time: match[0], amount });

                    // 金額を合計に加算
                    if (!isNaN(amount)) {
                        totalSettledAmount += amount;
                    }
                }
            }
        }
    });

    // 精算済の合計金額を表示
    document.getElementById('csv-total').textContent = '精算済 合計金額: ' + totalSettledAmount.toLocaleString() + ' 円';

    // 精算済と未精算の合計金額を表示
    displayFinalTotal();

    return csvTimes; // 照合用の時間リストを返す
}

// ±1分の誤差範囲を -1分から+2分に修正し、取引完了のみを対象にする
function compareTimesFromOutputItems(csvTimes) {
    const outputItems = document.querySelectorAll('.output-item');
    const results = [];

    outputItems.forEach((item, index) => {
        const timeText = item.querySelector('.time').textContent;
        const amountText = item.querySelector('.amount').textContent.replace(' 円', '').replace(/,/g, '');
        const statusText = item.querySelector('.status').textContent; // ステータスのテキストを取得
        const listAmount = parseFloat(amountText);

        let matched = false;

        // 取引完了のみを対象にする
        if (statusText === '取引完了') {
            const [listHour, listMinute] = timeText.split(':').map(Number);
            const listDate = new Date();
            listDate.setHours(listHour, listMinute, 0, 0); // 秒とミリ秒を0に設定

            csvTimes.forEach(csvTime => {
                const [csvHour, csvMinute] = csvTime.time.split(':').map(Number);
                const csvDate = new Date();
                csvDate.setHours(csvHour, csvMinute);

                const diff = listDate - csvDate; // 時間差をミリ秒単位で計算

                // -1分から+2分の範囲内かつ金額が一致する場合
                if (diff <= 60000 && diff >= -120000 && listAmount === csvTime.amount) {
                    matched = true;
                }
            });
        }

        results.push(matched);
    });

    return results;
}

// リストの枠の色を更新
function updateListColors(results) {
    const outputItems = document.querySelectorAll('.output-item');

    results.forEach((matched, index) => {
        if (matched) {
            outputItems[index].style.borderColor = 'green'; // 一致する場合は緑色
        } else {
            outputItems[index].style.borderColor = 'red'; // 一致しない場合は赤色
        }
    });
}

// CSVとリストの照合を行う
function processAndCompareCSV(content) {
    const csvTimes = parseCSV(content); // CSVから時間と金額を取得
    const results = compareTimesFromOutputItems(csvTimes); // output-itemから時間とステータスの照合
    updateListColors(results); // リストの色を更新
}


// ドラッグ＆ドロップの設定
const dropArea = document.getElementById('drop-area');

dropArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropArea.classList.add('dragover');
});

dropArea.addEventListener('dragleave', () => {
    dropArea.classList.remove('dragover');
});

dropArea.addEventListener('drop', (e) => {
    e.preventDefault();
    dropArea.classList.remove('dragover');

    const file = e.dataTransfer.files[0];
    const reader = new FileReader();

    reader.onload = (event) => {
        const decoder = new TextDecoder('windows-1252');  // ANSIの場合、windows-1252が多い
        const content = event.target.result;
        const decodedContent = decoder.decode(new Uint8Array(content));

        // 照合を実行
        processAndCompareCSV(decodedContent);
    };

    if (file) {
        reader.readAsArrayBuffer(file);  // ArrayBufferで読み込む
    }
});

// 未精算のCSVファイルを解析する関数
function parseUnsettledCSV(content) {
    const rows = content.split('\n');

    // 最初の行を分割して、7列目に「本日預り金(クレジット)」が含まれているかを確認
    const header = rows[0].split(',');

    if (header.length < 7 || !header[6].includes('本日預り金(クレジット)')) {
        console.log('CSVファイルがは「未精算預り金」である必要があります。');
        return; // 7列目に「本日預り金(クレジット)」がなければ処理をキャンセル
    }

    const unsettledTransactions = []; // 未精算の取引を保存するリスト

    const selectedDate = document.getElementById('date-picker').value; // 選択された日付を取得

    // 開始時刻：選択した日付の04:00
    const startTime = new Date(selectedDate + 'T04:00:00');

    // 終了時刻：次の日の03:59
    const endDate = new Date(selectedDate);
    endDate.setDate(endDate.getDate() + 1); // 日付を1日増加
    const endTime = new Date(endDate.toISOString().split('T')[0] + 'T03:59:59');

    // 最初の行（ヘッダー）を飛ばして2行目以降を処理
    rows.slice(1).forEach(row => {
        const cols = row.split(',');
        if (cols.length >= 7) {
            const dateTimeStr = cols[1]; // 日付は2列目にあると仮定
            const amountStr = cols[6]; // 7列目に金額が入ると仮定

            const match = dateTimeStr.match(/\d{4}\/\d{2}\/\d{2} \d{2}:\d{2}/); // 日付形式「YYYY/MM/DD HH:mm」を取得
            if (match) {
                const transactionTime = new Date(dateTimeStr); // 日付をDateオブジェクトに変換

                // 04:00から次の日03:59の範囲内であることを確認
                if (transactionTime >= startTime && transactionTime <= endTime) {
                    // 金額を数値に変換して保存
                    const amount = parseFloat(amountStr.replace(/,/g, '').replace(/[^\d.-]/g, '')); // 余分な文字を除去
                    if (!isNaN(amount)) {
                        unsettledTransactions.push({ time: dateTimeStr.split(' ')[1], amount: amount });
                    }
                }
            }
        }
    });

    // 未精算の取引と赤い枠の取引を照合して、青い枠に変更する
    updateToBlueIfMatched(unsettledTransactions);
}

// 赤い枠を青に変え、青に変わった枠の金額を合計する関数
function updateToBlueIfMatched(unsettledTransactions) {
    const outputItems = document.querySelectorAll('.output-item');
    totalBlueAmount = 0; // 未精算の金額を初期化

    outputItems.forEach((item, index) => {
        if (item.style.borderColor === 'red') { // 赤い枠の取引を対象にする
            const timeText = item.querySelector('.time').textContent;
            const amountText = item.querySelector('.amount').textContent.replace(' 円', '').replace(/,/g, '');
            const statusText = item.querySelector('.status').textContent; // ステータスのテキストを取得
            const listAmount = parseFloat(amountText);

            const [listHour, listMinute] = timeText.split(':').map(Number);
            const listDate = new Date();
            listDate.setHours(listHour, listMinute, 0, 0); // 秒とミリ秒を0に設定

            let matched = false;

            // 取引完了のみを対象にする
            if (statusText === '取引完了') {
                unsettledTransactions.forEach(unsettled => {
                    const [unsettledHour, unsettledMinute] = unsettled.time.split(':').map(Number);
                    const unsettledDate = new Date();
                    unsettledDate.setHours(unsettledHour, unsettledMinute, 0, 0); // 秒とミリ秒を0に設定

                    const diff = unsettledDate - listDate; // 時間差をミリ秒単位で計算

                    // -1分から+2分の範囲内かつ金額が一致する場合、青色に変更
                    console.log('debug:', listAmount, '  === ', unsettled.amount);
                    console.log('debug:', listDate, '  === ', unsettledDate, '  diff:', diff);
                    if (diff <= 60000 && diff >= -120000 && listAmount === unsettled.amount) {
                        matched = true;
                    }
                });
            }

            if (matched) {
                item.style.borderColor = 'blue'; // 一致した場合は青色
                totalBlueAmount += listAmount; // 青色に変わった取引の金額を合計
            }
        }
    });

    // 青色の枠の合計金額を表示
    document.getElementById('unsettled-total').textContent = '未精算 合計金額: ' + totalBlueAmount.toLocaleString() + ' 円';

    // 精算済と未精算の合計金額を表示
    displayFinalTotal();
}

// 未精算のCSVファイルを読み込むドラッグ＆ドロップ設定
const dropAreaUnsettled = document.getElementById('drop-area-unsettled');

dropAreaUnsettled.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropAreaUnsettled.classList.add('dragover');
});

dropAreaUnsettled.addEventListener('dragleave', () => {
    dropAreaUnsettled.classList.remove('dragover');
});

dropAreaUnsettled.addEventListener('drop', (e) => {
    e.preventDefault();
    dropAreaUnsettled.classList.remove('dragover');

    const file = e.dataTransfer.files[0];
    const reader = new FileReader();

    reader.onload = (event) => {
        const decoder = new TextDecoder('shift-jis');  // Shift-JISに変更
        const content = event.target.result;
        const decodedContent = decoder.decode(new Uint8Array(content));

        // 未精算のCSVを解析
        parseUnsettledCSV(decodedContent);
    };

    if (file) {
        reader.readAsArrayBuffer(file);  // ArrayBufferで読み込む
    }
});
